<?php
require_once 'lib/db.class.php';
include('config.php');
include('functions.php');
include('routing.php');
?>
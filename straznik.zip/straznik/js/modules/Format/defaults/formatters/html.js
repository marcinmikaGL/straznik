export default function(cell, formatterParams, onRendered){
	return cell.getValue();
}
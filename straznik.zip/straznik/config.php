<?php
DB::$host ="localhost";
DB::$dbName="pracownia";
DB::$user="root";
DB::$password="@tcc44100!!";
?>